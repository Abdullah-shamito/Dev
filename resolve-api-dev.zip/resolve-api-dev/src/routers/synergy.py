from fastapi import APIRouter, HTTPException
from src.app.neo4j_connector import neo4j_db

router = APIRouter()

@router.get("/{organization_id}/synergies")
def get_synergies(organization_id: str):
    query = """
    MATCH (a:Organization {id: $organization_id})-[r:SYNERGY_WITH]->(b:Organization)
    RETURN b.id AS id, b.name AS name, r.score AS score
    ORDER BY r.score DESC
    """
    try:
        results = neo4j_db.run_query(query, {"organization_id": organization_id})
        return {"synergies": results}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
