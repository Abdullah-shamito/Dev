# sync_service.py
from app.sync_logic import (
    sync_regions,
    sync_locations,
    sync_organization_types,
    sync_organizations,
    sync_categories,
    sync_projects,  # Add this line
    link_orgs_to_org_types,
    link_orgs_to_categories
)

if __name__ == "__main__":
    print(" Starting manual sync...")
    sync_regions()
    sync_locations()
    sync_organization_types()
    sync_organizations()
    sync_categories()
    sync_projects()  # Call this function
    link_orgs_to_org_types()
    link_orgs_to_categories()
    print(" Manual sync completed!")
