# preprocessing.py
import pandas as pd
import numpy as np
import ast
from sklearn.preprocessing import MultiLabelBinarizer, MinMaxScaler
import torch

def safe_parse(val):
    try:
        return ast.literal_eval(val) if isinstance(val, str) else []
    except:
        return []

def prepare_features(features_df):
    """
    Clean, encode, scale, and extract features (including embeddings).
    Returns a PyTorch tensor and a mapping from org_id to index.
    """
    df = features_df.copy().set_index('id')

    # Binary flags
    binary_cols = ['is_network', 'is_global', 'is_enriched']
    for col in binary_cols:
        df[col] = df[col].map({'t': 1, 'f': 0, True: 1, False: 0}).fillna(0).astype(int)

    # Parse lists
    for col in ['categories', 'sdgs', 'active_regions']:
        df[col] = df[col].fillna('[]').apply(safe_parse)

    # One-hot encode
    mlb_cat = MultiLabelBinarizer()
    cat_ohe = pd.DataFrame(mlb_cat.fit_transform(df['categories']), index=df.index)

    mlb_sdg = MultiLabelBinarizer()
    sdg_ohe = pd.DataFrame(mlb_sdg.fit_transform(df['sdgs']), index=df.index)

    mlb_reg = MultiLabelBinarizer()
    region_ohe = pd.DataFrame(mlb_reg.fit_transform(df['active_regions']), index=df.index)

    # Scale numeric
    numeric_cols = [
        'fundraising_score', 'investor_score', 'maturity_score', 'impact_score',
        'climate_score', 'linkedin_follower_count', 'type_confidence'
    ]
    scaler = MinMaxScaler()
    scaled_numeric = pd.DataFrame(
        scaler.fit_transform(df[numeric_cols].fillna(0)),
        index=df.index,
        columns=numeric_cols
    )

    # Combine all features (excluding embeddings for now)
    combined_df = pd.concat([
        scaled_numeric,
        df[binary_cols],
        cat_ohe,
        sdg_ohe,
        region_ohe
    ], axis=1)

    # Parse embeddings
    embedding_vectors = df['embedding'].apply(
        lambda x: np.array(ast.literal_eval(x)) if isinstance(x, str) else np.zeros(384)
    )
    embedding_matrix = np.stack(embedding_vectors.values)

    full_features = np.hstack([embedding_matrix, combined_df.values])
    id_to_idx = {org_id: idx for idx, org_id in enumerate(df.index)}

    return torch.tensor(full_features, dtype=torch.float32), id_to_idx
