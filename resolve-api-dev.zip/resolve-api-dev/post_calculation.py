from src.app.neo4j_connector import neo4j_db
from neo4j import GraphDatabase

# Use the configured driver
driver = neo4j_db.driver

def run_post_sync_calculations():
    with driver.session() as session:

        print("Tagging new organizations...")
        session.run("""
        MATCH (o:Organization)
        WHERE o.processed IS NULL
        SET o.processed = false
        """)

        print("Building SHARES_CATEGORIES_WITH relationships in batches...")
        session.run("""
        CALL apoc.periodic.iterate(
          'MATCH (o1:Organization) WHERE o1.processed = false RETURN o1',
          'MATCH (o1)-[:CATEGORIZED_AS]->(c:Category)<-[:CATEGORIZED_AS]-(o2:Organization)
           WHERE id(o1) < id(o2)
           WITH o1, o2, COUNT(DISTINCT c) AS intersectionSize
           MATCH (o1)-[:CATEGORIZED_AS]->(:Category)
           WITH o1, o2, intersectionSize, COUNT(*) AS total1
           MATCH (o2)-[:CATEGORIZED_AS]->(:Category)
           WITH o1, o2, intersectionSize, total1, COUNT(*) AS total2
           WITH o1, o2, (1.0 * intersectionSize) / (total1 + total2 - intersectionSize) AS jaccard
           WHERE jaccard >= 0.2
           MERGE (o1)-[:SHARES_CATEGORIES_WITH {score: jaccard, heuristic: true}]->(o2)',
          {batchSize: 50, parallel: false}
        )
        """)

        print("Building LOCATED_NEAR relationships (threshold 250km)...")
        session.run("""
        CALL apoc.periodic.iterate(
          'MATCH (o1:Organization) WHERE o1.processed = false RETURN o1',
          'MATCH (o1)-[:LOCATED_IN]->(l1:Location),
                (o2:Organization)-[:LOCATED_IN]->(l2:Location)
           WHERE id(o1) < id(o2)
             AND l1.latitude IS NOT NULL AND l1.longitude IS NOT NULL
             AND l2.latitude IS NOT NULL AND l2.longitude IS NOT NULL
           WITH o1, o2,
                point.distance(point({latitude: l1.latitude, longitude: l1.longitude}),
                               point({latitude: l2.latitude, longitude: l2.longitude})) AS geo_distance
           WHERE geo_distance < 250000
           MERGE (o1)-[:LOCATED_NEAR {distance: geo_distance}]->(o2)',
          {batchSize: 50, parallel: false}
        )
        """)

        print("Building ATTRACTS relationships...")
        session.run("""
        CALL apoc.periodic.iterate(
          'MATCH (a:Organization) WHERE a.processed = false AND a.fundraising_score IS NOT NULL RETURN a',
          'MATCH (b:Organization)
           WHERE b.investor_score IS NOT NULL
           WITH a, b, 1.0 - abs(a.fundraising_score - b.investor_score) AS similarity
           WHERE similarity >= 0.3
           MERGE (a)-[:ATTRACTS {score: similarity}]->(b)',
          {batchSize: 50, parallel: false}
        )
        """)

        print("Recomputing SYNERGY_WITH scores...")
        session.run("""
        MATCH (a:Organization)
        WHERE a.processed = false
        MATCH (a)-[r1:SHARES_CATEGORIES_WITH]->(b)
        OPTIONAL MATCH (a)-[r2:LOCATED_NEAR]->(b)
        OPTIONAL MATCH (a)-[r3:ALIGNED_ON_SDG]->(b)
        OPTIONAL MATCH (a)-[r4:ATTRACTS]->(b)
        WITH a, b,
             COALESCE(r1.score, 0) * 0.4 +
             (1 - COALESCE(r2.distance, 100000)/100000) * 0.2 +
             COALESCE(r3.score, 0) * 0.2 +
             COALESCE(r4.score, 0) * 0.2 AS synergyScore
        WHERE synergyScore > 0.2
        MERGE (a)-[r:SYNERGY_WITH]->(b)
        SET r.score = synergyScore
        """)

        print("Refreshing graph projections...")
        session.run("CALL gds.graph.drop('orgSimilarityGraph', false)")
        session.run("""
        CALL gds.graph.project(
          'orgSimilarityGraph',
          {
            Organization: {
              properties: ['node2vec_embedding']
            }
          },
          {
            SHARES_CATEGORIES_WITH: {orientation: 'UNDIRECTED'},
            LOCATED_NEAR: {orientation: 'UNDIRECTED'},
            ALIGNED_ON_SDG: {orientation: 'UNDIRECTED'},
            ATTRACTS: {orientation: 'UNDIRECTED'}
          }
        )
        """)

        print("Running Node2Vec...")
        session.run("""
        CALL gds.node2vec.write('orgSimilarityGraph', {
          embeddingDimension: 64,
          walkLength: 20,
          iterations: 10,
          walksPerNode: 5,
          windowSize: 5,
          writeProperty: 'node2vec_embedding'
        })
        YIELD nodePropertiesWritten
        """)

        print("Building SIMILAR_TO relationships using Node2Vec embeddings...")
        session.run("""
        CALL apoc.periodic.iterate(
          'MATCH (o1:Organization) WHERE o1.processed = false RETURN o1',
          'MATCH (o2:Organization)
           WHERE id(o1) < id(o2)
             AND o1.node2vec_embedding IS NOT NULL
             AND o2.node2vec_embedding IS NOT NULL
           WITH o1, o2,
                gds.similarity.cosine(o1.node2vec_embedding, o2.node2vec_embedding) AS sim
           WHERE sim >= 0.5
           MERGE (o1)-[:SIMILAR_TO {score: sim}]->(o2)',
          {batchSize: 50, parallel: false}
        )
        """)

        print("Running Louvain Community Detection...")
        session.run("""
        CALL gds.louvain.write('orgSimilarityGraph', {
          writeProperty: 'community'
        })
        YIELD communityCount
        """)

        print("Marking newly processed organizations as done")
        session.run("""
        MATCH (o:Organization)
        WHERE o.processed = false
        SET o.processed = true
        """)

if __name__ == "__main__":
    run_post_sync_calculations()
    print(" Post-sync calculations complete!")
