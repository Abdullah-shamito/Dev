import psycopg2
import os
from dotenv import load_dotenv

load_dotenv()

POSTGRES_URI = os.getenv("POSTGRES_URI")
sslmode="require"

pg_conn = psycopg2.connect(POSTGRES_URI)
pg_cursor = pg_conn.cursor()

def fetch_data(query):
    pg_cursor.execute(query)
    return pg_cursor.fetchall()

def close_pg_connection():
    pg_cursor.close()
    pg_conn.close()

