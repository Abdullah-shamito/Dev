from fastapi import FastAPI
from src.routers import graph, relationships, sync, spaces, synergy  # Add synergy

app = FastAPI()

# Create a v1 prefix for all existing routes
v1_prefix = "/v1"


# Include routers
app.include_router(graph.router, prefix=v1_prefix + "/graph", tags=["Graph"])
app.include_router(relationships.router, prefix=v1_prefix + "/organizations", tags=["Organizations"])
app.include_router(sync.router, prefix=v1_prefix + "/sync", tags=["Sync"])
app.include_router(spaces.router, prefix=v1_prefix + "/spaces", tags=["Spaces"])
app.include_router(synergy.router, prefix=v1_prefix + "/synergy", tags=["Synergy"])  # Register
