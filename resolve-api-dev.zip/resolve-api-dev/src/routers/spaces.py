from fastapi import APIRouter, HTTPException, Query
from src.app.neo4j_connector import neo4j_db

router = APIRouter()

@router.get("/")
def get_spaces():
    query = """
    MATCH (s:Space)
    RETURN s.id AS id, s.name AS name
    """
    spaces = neo4j_db.run_query(query)

    if not spaces:
        raise HTTPException(status_code=404, detail="No spaces found")

    return {"spaces": spaces}


@router.get("/{space_id}/relationships")
def get_space_relationships(space_id: str, limit: int = Query(default=None, ge=1)):
    query = """
<<<<<<< HEAD
    MATCH (s:Space {id: $space_id})-[:BELONGS_TO]->(org:Organization)
    OPTIONAL MATCH (org)-[syn:SYNERGY_WITH]->(otherOrg:Organization)
    RETURN 
        org.id AS organization_id,
        org.name AS organization_name,
        TYPE(syn) AS relationship,
        otherOrg.id AS target_id,
        otherOrg.name AS target_name,
        syn.score AS synergy_score
    ORDER BY synergy_score DESC
    LIMIT 20
=======
    MATCH (s:Space {id: $space_id})-[:BELONGS_TO]->(org1:Organization)
    MATCH (s)-[:BELONGS_TO]->(org2:Organization)
    WHERE id(org1) < id(org2)
    OPTIONAL MATCH (org1)-[r:SYNERGY_WITH]->(org2)
    RETURN 
      s.id AS space_id, 
      org1.id AS organization_a, 
      org2.id AS organization_b, 
      COALESCE(r.score, 0.0) AS synergy
>>>>>>> cef8b33ee2da1e1064363e21de049e89278c7736
    """

<<<<<<< HEAD
    if not result:
        raise HTTPException(status_code=404, detail="No relationships or synergies found for this space")

    return {"space_id": space_id, "synergies": result}
=======
    if limit:
        query += f"\nLIMIT {limit}"

    records = neo4j_db.run_query(query, {"space_id": space_id})

    if not records:
        raise HTTPException(status_code=404, detail="No relationships or synergies found for this space")

    synergies = [
        {
            "organization_a": row["organization_a"],
            "organization_b": row["organization_b"],
            "synergy": float(row["synergy"] or 0.0)  
        }
        for row in records
    ]

    return {
        "space_id": space_id,
        "synergies": synergies
    }
>>>>>>> cef8b33ee2da1e1064363e21de049e89278c7736
