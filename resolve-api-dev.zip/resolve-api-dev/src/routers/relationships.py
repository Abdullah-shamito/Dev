from fastapi import APIRouter, HTTPException
from src.app.neo4j_connector import neo4j_db

router = APIRouter()

@router.get("/{organization_id}/relationships")
def get_organization_relationships(organization_id: str):
    query = """
    MATCH (o:Organization {id: $organization_id})-[r]-(n)
    RETURN TYPE(r) AS relationship, labels(n) AS target_labels, n.id AS target_id, 
           n.name AS target_name, n.investor_score AS investor_score
    """
    result = neo4j_db.run_query(query, {"organization_id": organization_id})
    
    if not result:
        raise HTTPException(status_code=404, detail="No relationships found for this organization")

    return {"organization_id": organization_id, "relationships": result}
