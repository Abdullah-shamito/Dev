# app/periodic_sync.py
from app.sync_logic import (
    sync_regions,
    sync_locations,
    sync_organization_types,
    sync_organizations,
    sync_categories,
    link_orgs_to_org_types,
    link_orgs_to_categories,
    sync_projects  # Add this line
)
from apscheduler.schedulers.background import BackgroundScheduler

def run_all_sync():
    sync_regions()
    sync_locations()
    sync_organization_types()
    sync_organizations()
    sync_categories()
    sync_projects()  # Call this function
    link_orgs_to_org_types()
    link_orgs_to_categories()
    print("All data synced successfully!")

# Set up the scheduler for periodic sync every hour
scheduler = BackgroundScheduler()
scheduler.add_job(run_all_sync, 'interval', hours=12)
scheduler.start()
