## Getting started

This project uses [uv](https://docs.astral.sh/uv/) as the package manager.

### Prerequisites

- Python 3.11 or higher
- [uv](https://docs.astral.sh/uv/) package manager

### Local Development Setup

1. Install [uv](https://docs.astral.sh/uv/getting-started/installation/) if you haven't already
2. Create virtual environment using `uv venv`
3. Activate virtual environment
   1. on Mac/Linux: `source .venv/bin/activate`
   2. on Windows: `.venv\Scripts\activate`
4. Install dependencies using `uv sync`
5. Set environment variables by copying the `.env.sample` file to `.env` and editing the variables
6. Run the development server with `uv run uvicorn main:app --reload --host 0.0.0.0 --port 8000`
