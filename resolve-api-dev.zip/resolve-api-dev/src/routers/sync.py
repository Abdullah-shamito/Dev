from fastapi import APIRouter
from app.sync_logic import run_all_sync  # ✅ Ensure this line is correct

router = APIRouter()

@router.post("/manual")
def trigger_manual_sync():
    """Manually triggers the synchronization process."""
    run_all_sync()
    return {"message": "Manual sync triggered successfully"}
