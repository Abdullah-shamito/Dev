import json
import decimal
import logging
from app.neo4j_connector import neo4j_db
from app.postgres_connector import fetch_data

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

### Helper Functions ###
def convert_decimal(value):
    """Convert PostgreSQL Decimal values to float."""
    if isinstance(value, decimal.Decimal):
        return float(value)
    return value

def convert_embedding(value):
    """Ensure embeddings are stored as a JSON list or set to None if empty."""
    if value is None:
        return None  # Explicitly return None for missing values
    elif isinstance(value, str):
        try:
            parsed_value = json.loads(value)  # Convert JSON string to list
            if isinstance(parsed_value, list):
                return parsed_value
            logger.warning(f"Embedding is not a list: {parsed_value}")
            return None
        except json.JSONDecodeError:
            logger.warning("Failed to parse embedding string as JSON, returning None")
            return None
    elif isinstance(value, list):
        return value
    else:
        logger.warning(f"Unexpected embedding type: {type(value)}, returning None")
        return None

def safe_execute(func, error_message="Operation failed"):
    """Execute a function with error handling."""
    try:
        return func()
    except Exception as e:
        logger.error(f"{error_message}: {str(e)}")
        return None

### Sync Functions ###
def sync_regions():
    """Synchronize Regions from PostgreSQL to Neo4j."""
    try:
        query = "SELECT id, name, slug FROM regions;"
        regions_data = fetch_data(query)
        
        if not regions_data:
            logger.warning("No regions found to sync")
            return
        
        cypher_query = """
        UNWIND $regions AS region
        MERGE (r:Region {id: region.id})
        ON CREATE SET r.name = region.name, r.slug = region.slug
        ON MATCH SET r.name = region.name, r.slug = region.slug;
        """
        
        neo4j_db.run_query(cypher_query, {
            "regions": [
                {"id": r[0], "name": r[1], "slug": r[2]} 
                for r in regions_data
            ]
        })
        logger.info(f"Synced {len(regions_data)} regions")
    except Exception as e:
        logger.error(f"Error syncing regions: {str(e)}")

def extract_location_data(google_json_dump):
    """Extracts relevant fields from google_json_dump"""
    if not google_json_dump:
        return None, None  # Return None if no data available

    try:
        # If it's already a dict, use it. Otherwise, parse JSON string.
        if isinstance(google_json_dump, str):
            data = json.loads(google_json_dump)
        elif isinstance(google_json_dump, dict):
            data = google_json_dump
        else:
            logger.warning(f"Unexpected type for google_json_dump: {type(google_json_dump)}")
            return None, None

        latitude = data["geometry"]["location"]["lat"]
        longitude = data["geometry"]["location"]["lng"]
        return latitude, longitude
    except (KeyError, json.JSONDecodeError, TypeError):
        logger.warning(f"Invalid google_json_dump format: {google_json_dump}")
        return None, None  # Return None on error

def sync_locations():
    """Synchronize Locations and their relationships to Regions, including latitude & longitude."""
    try:
        query = """
        SELECT 
            id, 
            name, 
            country_id, 
            region_id, 
            formatted_address, 
            google_place_id, 
            google_json_dump
        FROM locations;
        """
        locations_data = fetch_data(query)

        if not locations_data:
            logger.warning("No locations found to sync")
            return

        processed_locations = []
        for loc in locations_data:
            latitude, longitude = extract_location_data(loc[6])  # Extract lat/lon
            processed_locations.append({
                "id": loc[0],
                "name": loc[1],
                "country_id": loc[2],
                "region_id": loc[3],
                "formatted_address": loc[4],
                "google_place_id": loc[5],
                "latitude": latitude,   # Store extracted latitude
                "longitude": longitude  # Store extracted longitude
            })

        # Create Location nodes and store latitude & longitude
        cypher_query = """
        UNWIND $locations AS location
        MERGE (l:Location {id: location.id})
        ON CREATE SET 
            l.name = location.name, 
            l.country_id = location.country_id,
            l.formatted_address = location.formatted_address,
            l.google_place_id = location.google_place_id,
            l.latitude = location.latitude,
            l.longitude = location.longitude
        ON MATCH SET 
            l.name = location.name, 
            l.country_id = location.country_id,
            l.formatted_address = location.formatted_address,
            l.google_place_id = location.google_place_id,
            l.latitude = location.latitude,
            l.longitude = location.longitude

        WITH l, location
        WHERE location.region_id IS NOT NULL
        MATCH (r:Region {id: location.region_id})
        MERGE (l)-[:BELONGS_TO]->(r);
        """

        neo4j_db.run_query(cypher_query, {"locations": processed_locations})

        logger.info(f"Synced {len(processed_locations)} locations with latitude & longitude")

    except Exception as e:
        logger.error(f"Error syncing locations: {str(e)}")

def sync_organization_types():
    """Synchronize Organization Types from PostgreSQL to Neo4j."""
    try:
        query = "SELECT organization_type_id, organization_type_name FROM organization_types;"
        org_types = fetch_data(query)
        
        if not org_types:
            logger.warning("No organization types found to sync")
            return
        
        cypher_query = """
        UNWIND $org_types AS type
        MERGE (t:OrgType {id: type.id})
        ON CREATE SET t.name = type.name
        ON MATCH SET t.name = type.name;
        """
        
        neo4j_db.run_query(cypher_query, {
            "org_types": [
                {"id": ot[0], "name": ot[1]} 
                for ot in org_types
            ]
        })
        logger.info(f"Synced {len(org_types)} organization types")
    except Exception as e:
        logger.error(f"Error syncing organization types: {str(e)}")

def sync_categories():
    """Synchronize Categories from PostgreSQL to Neo4j."""
    try:
        query = "SELECT id, name, slug FROM categories;"
        categories_data = fetch_data(query)
        
        if not categories_data:
            logger.warning("No categories found to sync")
            return
        
        cypher_query = """
        UNWIND $categories AS category
        MERGE (c:Category {id: category.id})
        ON CREATE SET c.name = category.name, c.slug = category.slug
        ON MATCH SET c.name = category.name, c.slug = category.slug;
        """
        
        neo4j_db.run_query(cypher_query, {
            "categories": [
                {"id": c[0], "name": c[1], "slug": c[2]} 
                for c in categories_data
            ]
        })
        logger.info(f"Synced {len(categories_data)} categories")
    except Exception as e:
        logger.error(f"Error syncing categories: {str(e)}")

def sync_spaces():
    """Synchronize Spaces from PostgreSQL to Neo4j."""
    try:
        query = "SELECT id, name, slug FROM spaces;"
        spaces_data = fetch_data(query)
        
        if not spaces_data:
            logger.warning("No spaces found to sync")
            return
        
        cypher_query = """
        UNWIND $spaces AS space
        MERGE (s:Space {id: space.id})
        ON CREATE SET s.name = space.name, s.slug = space.slug
        ON MATCH SET s.name = space.name, s.slug = space.slug;
        """
        
        neo4j_db.run_query(cypher_query, {
            "spaces": [
                {"id": s[0], "name": s[1], "slug": s[2]} 
                for s in spaces_data
            ]
        })
        logger.info(f"Synced {len(spaces_data)} spaces")
    except Exception as e:
        logger.error(f"Error syncing spaces: {str(e)}")

def sync_organizations():
    """
    Synchronize Organizations with all their properties and relationships.
    This combines both original sync_organizations functions.
    """
    try:
        query = """
            SELECT 
                o.id, o.name, o.location_id, oot.organization_type_id,
                o.embedding, o.is_global, o.linkedin_follower_count,
                o.investor_score, o.fundraising_score, o.maturity_score,
                o.impact_score, o.climate_score, o.linkedin_url, o.website_url, 
                o.description, o.sdgs 
            FROM organizations o
            LEFT JOIN organizations_organization_types oot ON o.id = oot.organization_id;
        """
        organizations = fetch_data(query)
        
        if not organizations:
            logger.warning("No organizations found to sync")
            return

        # Process data before sending to Neo4j
        processed_orgs = []
        for org in organizations:
            sdgs_cleaned = [sdg for sdg in org[15] if sdg is not None] if org[15] else []
            processed_org = {
                "id": org[0],
                "name": org[1],
                "location_id": org[2],
                "organization_type_id": org[3],
                "embedding": convert_embedding(org[4]),  # Use the updated function
                "is_global": org[5],
                "linkedin_follower_count": convert_decimal(org[6]),
                "investor_score": convert_decimal(org[7]),
                "fundraising_score": convert_decimal(org[8]),
                "maturity_score": convert_decimal(org[9]),
                "impact_score": convert_decimal(org[10]),
                "climate_score": convert_decimal(org[11]),
                "linkedin_url": org[12],
                "website_url": org[13],
                "description": org[14],
                "sdgs": sdgs_cleaned
            }
            processed_orgs.append(processed_org)

        # 1. Create or update Organization nodes with all properties
        create_nodes_query = """
        UNWIND $organizations AS org
        MERGE (o:Organization {id: org.id})
        ON CREATE SET 
            o.name = org.name,
            o.embedding = org.embedding,
            o.is_global = org.is_global,
            o.linkedin_follower_count = org.linkedin_follower_count,
            o.investor_score = org.investor_score,
            o.fundraising_score = org.fundraising_score,
            o.maturity_score = org.maturity_score,
            o.impact_score = org.impact_score,
            o.climate_score = org.climate_score,
            o.linkedin_url = org.linkedin_url,
            o.website_url = org.website_url,
            o.description = org.description,
            o.sdgs = org.sdgs
        ON MATCH SET
            o.name = org.name,
            o.embedding = org.embedding,
            o.is_global = org.is_global,
            o.linkedin_follower_count = org.linkedin_follower_count,
            o.investor_score = org.investor_score,
            o.fundraising_score = org.fundraising_score,
            o.maturity_score = org.maturity_score,
            o.impact_score = org.impact_score,
            o.climate_score = org.climate_score,
            o.linkedin_url = org.linkedin_url,
            o.website_url = org.website_url,
            o.description = org.description,
            o.sdgs = org.sdgs;
        """
        
        neo4j_db.run_query(create_nodes_query, {"organizations": processed_orgs})
        logger.info(f"Synced {len(processed_orgs)} organization nodes")

        # 2. Link Organizations to Locations
        location_orgs = [{"id": org["id"], "location_id": org["location_id"]} 
                         for org in processed_orgs if org["location_id"] is not None]
        
        if location_orgs:
            link_locations_query = """
            UNWIND $organizations AS org
            MATCH (o:Organization {id: org.id}), (l:Location {id: org.location_id})
            MERGE (o)-[:LOCATED_IN]->(l);
            """
            
            neo4j_db.run_query(link_locations_query, {"organizations": location_orgs})
            logger.info(f"Linked {len(location_orgs)} organizations to locations")

        # 3. Link Organizations to Organization Types
        type_orgs = [{"id": org["id"], "organization_type_id": org["organization_type_id"]} 
                     for org in processed_orgs if org["organization_type_id"] is not None]
        
        if type_orgs:
            link_types_query = """
            UNWIND $organizations AS org
            MATCH (o:Organization {id: org.id}), (t:OrgType {id: org.organization_type_id})
            MERGE (o)-[:CLASSIFIED_AS]->(t);
            """
            
            neo4j_db.run_query(link_types_query, {"organizations": type_orgs})
            logger.info(f"Linked {len(type_orgs)} organizations to organization types")
    
    except Exception as e:
        logger.error(f"Error syncing organizations: {str(e)}")

def link_orgs_to_categories():
    """Link Organizations to Categories based on their relationships."""
    try:
        query = "SELECT organization_id, category_id FROM organizations_categories;"
        relations = fetch_data(query)
        
        if not relations:
            logger.warning("No organization-category relationships found to sync")
            return
        
        cypher_query = """
        UNWIND $relations AS rel
        MATCH (o:Organization {id: rel.organization_id}), 
              (c:Category {id: rel.category_id})
        MERGE (o)-[:CATEGORIZED_AS]->(c);
        """
        
        neo4j_db.run_query(cypher_query, {
            "relations": [
                {"organization_id": r[0], "category_id": r[1]} 
                for r in relations
            ]
        })
        logger.info(f"Linked {len(relations)} organizations to categories")
    except Exception as e:
        logger.error(f"Error linking organizations to categories: {str(e)}")

def link_spaces_to_organizations():
    """Link Spaces to Organizations based on their relationships."""
    try:
        query = "SELECT space_id, organization_id FROM spaces_organizations;"
        relations_data = fetch_data(query)
        
        if not relations_data:
            logger.warning("No space-organization relationships found to sync")
            return
        
        cypher_query = """
        UNWIND $relations AS rel
        MATCH (s:Space {id: rel.space_id}), 
              (o:Organization {id: rel.organization_id})
        MERGE (s)-[:BELONGS_TO]->(o);
        """
        
        neo4j_db.run_query(cypher_query, {
            "relations": [
                {"space_id": r[0], "organization_id": r[1]} 
                for r in relations_data
            ]
        })
        logger.info(f"Linked {len(relations_data)} spaces to organizations")
    except Exception as e:
        logger.error(f"Error linking spaces to organizations: {str(e)}")

def sync_projects():
    """Synchronize Projects and their relationships to Organizations."""
    try:
        query = """
            SELECT 
                p.id, 
                p.name, 
                p.organization_id
            FROM 
                projects p;
        """
        projects = fetch_data(query)
        
        if not projects:
            logger.warning("No projects found to sync")
            return
        
        # 1. Create Project nodes
        create_projects_query = """
        UNWIND $projects AS project
        MERGE (p:Project {id: project.id})
        ON CREATE SET p.name = project.name
        ON MATCH SET p.name = project.name;
        """
        
        neo4j_db.run_query(create_projects_query, {
            "projects": [
                {"id": project[0], "name": project[1]} 
                for project in projects
            ]
        })
        logger.info(f"Synced {len(projects)} project nodes")

        # 2. Link Projects to Organizations
        org_projects = [{"id": project[0], "organization_id": project[2]} 
                         for project in projects if project[2] is not None]
        
        if org_projects:
            link_organizations_query = """
            UNWIND $projects AS project
            MATCH (p:Project {id: project.id}),
                  (o:Organization {id: project.organization_id})
            MERGE (p)-[:BELONGS_TO]->(o);
            """
            
            neo4j_db.run_query(link_organizations_query, {"projects": org_projects})
            logger.info(f"Linked {len(org_projects)} projects to organizations")
    except Exception as e:
        logger.error(f"Error syncing projects: {str(e)}")

def run_all_sync(batch_size=1000):
    """
    Triggers all synchronization functions at once.
    
    Args:
        batch_size: The number of records to process in one batch
    """
    try:
        logger.info("Starting full database synchronization...")
        
        # Execute all sync functions in logical order
        sync_regions()
        sync_locations()
        sync_organization_types()
        sync_categories()
        sync_organizations()
        link_orgs_to_categories()
        sync_projects()
        sync_spaces()
        link_spaces_to_organizations()
        
        logger.info("Full database synchronization completed successfully!")
    except Exception as e:
        logger.error(f"Error during full database synchronization: {str(e)}")