from fastapi import APIRouter
from src.app.neo4j_connector import neo4j_db

router = APIRouter()

@router.get("/")
def get_graph():
    query_nodes = """
  MATCH (n:Organization)
RETURN n.id AS id, labels(n) AS labels, properties(n) AS properties
LIMIT 100

    """
    query_edges = """
    MATCH (a)-[r]->(b)
    WHERE a.id IS NOT NULL AND b.id IS NOT NULL
    RETURN DISTINCT a.id AS source, TYPE(r) AS relationship, b.id AS target
    """

    nodes = neo4j_db.run_query(query_nodes)
    edges = neo4j_db.run_query(query_edges)

    return {"nodes": nodes, "edges": edges}
